// Acho que é melhor completar ou modificar o código abaixo:


const btnAdicionar = document.getElementById("btn-adicionar");
const ajudaTotal = document.getElementById("ajuda-total");
const ajudaMedia = document.getElementById("ajuda-total");
const txtPessoa = document.getElementById("txtpessoa");


const AJUDAS = [];


function atualizarTotal(){
    // substituir código abaixo
    ajudaTotal.innerHTML = "R$ 120.00";
}

function atualizarMedia(){
    // substituir código abaixo
    ajudaTotal.innerHTML = "R$ 12.00";
}

function removerAjuda(id){
    // completar
    alert(id);
}

function listarAjudas(){
    //  completar
}

btnAdicionar.addEventListener("click", ()=>{

    // completar
    alert("ADICIONAR AJUDA");

});


listarAjudas();
atualizarTotal();
