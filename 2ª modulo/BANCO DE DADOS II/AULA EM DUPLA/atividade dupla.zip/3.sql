insert into setor_vaga (idsetor, idvaga) values (1, 1);
insert into setor_vaga (idsetor, idvaga) values (2, 2);
insert into setor_vaga (idsetor, idvaga) values (3, 3);
insert into setor_vaga (idsetor, idvaga) values (4, 4);
insert into setor_vaga (idsetor, idvaga) values (5, 5);
