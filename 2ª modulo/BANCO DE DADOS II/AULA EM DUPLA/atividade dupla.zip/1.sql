insert into administrador (idadmin, nome, email, senha) values (1, 'Sarita Gibbe', 'sgibbe0@google.com.au', 'jM5~FCJn{');
insert into administrador (idadmin, nome, email, senha) values (2, 'Rosabella Beverage', 'rbeverage1@guardian.co.uk', 'wK7''ckDq');
insert into administrador (idadmin, nome, email, senha) values (3, 'Cinnamon Jentet', 'cjentet2@cdc.gov', 'bM0>L=\i#{');
insert into administrador (idadmin, nome, email, senha) values (4, 'Northrup Thorndycraft', 'nthorndycraft3@ed.gov', 'eW5%YPs&KUM>');
insert into administrador (idadmin, nome, email, senha) values (5, 'Fianna Lyven', 'flyven4@1und1.de', 'yH2}sl"@"`');
