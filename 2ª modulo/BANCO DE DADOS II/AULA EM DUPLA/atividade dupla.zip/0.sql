insert into setor (idsetor, nome, salario, jornada) values (1, 'Pharmaceutical', 1395.94, 40);
insert into setor (idsetor, nome, salario, jornada) values (2, 'Engineering', 1213.48, 40);
insert into setor (idsetor, nome, salario, jornada) values (3, 'Public Utilities', 1654.83, 40);
insert into setor (idsetor, nome, salario, jornada) values (4, 'Basic Industries', 1026.38, 40);
insert into setor (idsetor, nome, salario, jornada) values (5, 'Human Resources', 2559.44, 40);
