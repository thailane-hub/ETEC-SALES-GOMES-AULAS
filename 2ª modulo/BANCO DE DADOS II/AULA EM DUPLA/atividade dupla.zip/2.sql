insert into vaga (idvaga, descricao, prazoinicial, prazofinal, idadmin) values (1, 'Dut eros. Suspendisse accumsan tortor quis. Sed ante.', '2023-10-10 17:59:45', '2023-09-20 00:57:02', 1);
insert into vaga (idvaga, descricao, prazoinicial, prazofinal, idadmin) values (2, 'Duis bibendum, felis sed a justo. Aliquam quis turpi.', '2024-04-21 12:54:10', '2023-12-23 10:34:39', 2);
insert into vaga (idvaga, descricao, prazoinicial, prazofinal, idadmin) values (3, 'Cum sociis natoque penat ma In blandit ultrices enim.', '2023-06-28 19:19:23', '2024-05-03 10:53:20', 3);
insert into vaga (idvaga, descricao, prazoinicial, prazofinal, idadmin) values (4, 'In hac habitasse platea dictumst. Morbi vestibulum,is', '2023-07-02 09:49:20', '2024-02-29 05:35:12', 4);
insert into vaga (idvaga, descricao, prazoinicial, prazofinal, idadmin) values (5, 'Nulla tellus. In sagittis dui vel nisl. Duis ac nibh.', '2024-02-06 16:57:10', '2023-10-15 16:46:24', 5);
